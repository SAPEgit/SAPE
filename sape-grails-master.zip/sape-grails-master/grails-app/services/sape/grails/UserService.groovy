package sape.grails

import grails.gorm.transactions.Transactional

@Transactional
class UserService {

    def serviceMethod() {

    }
}
