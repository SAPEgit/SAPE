package sape.grails

class UserController {

    def index() { }
}
